"use client"

import { usePathname } from "next/navigation"
import { Bell, Search } from "lucide-react"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { notifications } from "@/lib/mock-data"

const pageTitles: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/servers": "Servers",
  "/databases": "Databases",
  "/network": "Network",
  "/security": "Security",
  "/communications": "Communications",
  "/settings": "Settings",
}

export function AppHeader() {
  const pathname = usePathname()
  const currentTitle = pageTitles[pathname] || "Dashboard"
  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b border-slate-700/50 bg-slate-950/80 px-4 backdrop-blur-sm">
      <SidebarTrigger className="text-slate-400 hover:text-slate-100" />
      <Separator orientation="vertical" className="h-5 bg-slate-700/50" />

      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-slate-100">{currentTitle}</span>
        <Badge variant="outline" className="bg-slate-800/50 text-cyan-400 border-cyan-500/50 text-[10px] font-mono">
          <span className="mr-1 h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse inline-block" />
          LIVE
        </Badge>
      </div>

      <div className="ml-auto flex items-center gap-3">
        <div className="hidden md:flex items-center gap-1.5 rounded-full bg-slate-800/60 px-3 py-1.5 border border-slate-700/50">
          <Search className="h-3.5 w-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search systems..."
            className="w-36 bg-transparent text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none"
          />
        </div>

        <Button variant="ghost" size="icon" className="relative text-slate-400 hover:text-slate-100">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-cyan-500 text-[9px] font-bold text-slate-950">
              {unreadCount}
            </span>
          )}
          <span className="sr-only">Notifications</span>
        </Button>

        <Separator orientation="vertical" className="h-5 bg-slate-700/50 hidden md:block" />

        <div className="hidden md:flex items-center gap-2">
          <Avatar className="h-7 w-7">
            <AvatarFallback className="bg-slate-800 text-cyan-400 text-xs font-bold border border-slate-700">
              CM
            </AvatarFallback>
          </Avatar>
          <span className="text-xs text-slate-400">Admin</span>
        </div>
      </div>
    </header>
  )
}
