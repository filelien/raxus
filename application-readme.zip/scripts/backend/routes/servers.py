"""
NEXUS OS - Server Management Endpoints
=======================================
CRUD operations for server management.
"""

from fastapi import APIRouter, HTTPException, Depends
from typing import List

# from models import ServerCreate, ServerResponse, ServerStatus
# from services.ssh_manager import SSHManager

router = APIRouter()

# ---------- Endpoints ----------

@router.get("/", response_model=list)
async def list_servers():
    """List all registered servers with current status."""
    # db = get_db()
    # servers = await db.fetch_all(query=servers_table.select())
    # return [ServerResponse.from_orm(s) for s in servers]
    return []

@router.get("/{server_id}")
async def get_server(server_id: str):
    """Get detailed information about a specific server."""
    # server = await db.fetch_one(query=servers_table.select().where(servers_table.c.id == server_id))
    # if not server:
    #     raise HTTPException(status_code=404, detail="Server not found")
    # return ServerResponse.from_orm(server)
    return {"id": server_id}

@router.post("/", status_code=201)
async def create_server():
    """Register a new server for monitoring."""
    # Validate connection via SSH
    # ssh = SSHManager()
    # connected = await ssh.test_connection(server.ip_address, server.ssh_user, server.ssh_port)
    # if not connected:
    #     raise HTTPException(status_code=400, detail="Cannot connect to server via SSH")
    # Insert into database
    # return ServerResponse.from_orm(new_server)
    return {"status": "created"}

@router.put("/{server_id}")
async def update_server(server_id: str):
    """Update server configuration."""
    return {"id": server_id, "status": "updated"}

@router.delete("/{server_id}", status_code=204)
async def delete_server(server_id: str):
    """Remove a server from monitoring."""
    return None

@router.post("/{server_id}/restart")
async def restart_server(server_id: str):
    """Send restart command to a server via SSH."""
    # ssh = SSHManager()
    # result = await ssh.execute_command(server_id, "sudo reboot")
    return {"id": server_id, "action": "restart", "status": "initiated"}
